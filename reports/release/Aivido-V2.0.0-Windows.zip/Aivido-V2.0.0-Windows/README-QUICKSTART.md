# Aivido V2.0.0 Windows

Install Python 3.9+ and run install-aivido.cmd. The installer creates a new local .venv and installs requirements.txt from PyPI. See docs/SECOND_SYSTEM_INSTALL.md for prerequisites and acceptance instructions.
