"""movie_render_queue.py — Unreal Movie Render Queue (MRQ) driver.

Two contracts, both honest:

1. ``probe()`` — detects whether the live editor exposes the Movie Render
   Queue subsystem at all (the plugin must be enabled in the project).
   Returns structured evidence; never assumes support.

2. ``render_sequence()`` — issues a real MRQ render through the subsystem
   when the probe passes. When the probe fails, it returns a truthful
   BLOCKED result (``blocked: "movie_render_queue"``) instead of pretending
   a render happened.

3. ``render_real_frames()`` — NOT MRQ: deterministic per-sample high-res
   captures of real Unreal frames while the level-viewport camera is moved
   along a shot pose path. Exists so the quality loop and demo always have
   real-frame proof even where MRQ is unavailable. The produced files are
   real Unreal renderer output, labeled exactly as such.

No code in this module imports ``unreal`` on the host: everything is emitted
editor-side python through UnrealBridge.execute_python, matching the gap-tool
convention. Results pass through ``__bridge_result__`` verbatim — errors from
the engine are never converted into success.
"""

from __future__ import annotations

import json
import math
import os
import time
from typing import Any, Callable, Dict, List, Optional

# Resolution presets the renderer honors (1920x1080 default, 4K optional).
RESOLUTION_PRESETS = {
    "1080p": (1920, 1080),
    "1920x1080": (1920, 1080),
    "4k": (3840, 2160),
    "3840x2160": (3840, 2160),
}


def _payload(res: Any) -> Any:
    """Tolerate both bridge wrappings: nested {"ok":.., "result": <payload>}
    and flat payloads, mirroring the canonical tools handling."""
    if isinstance(res, dict) and isinstance(res.get("result"), (dict, list)):
        return res["result"]
    return res


class MovieRenderQueueDriver:
    def __init__(self, bridge) -> None:
        self.bridge = bridge

    # ------------------------------------------------------------------ probe
    # UE 5.4+ renamed the python-visible surface: MovieRenderQueueSubsystem /
    # MoviePipelineEditorExecutor became MoviePipelineQueueSubsystem /
    # MoviePipelinePIEExecutor (older names are still accepted when present).
    _SUBSYSTEM_NAMES = ("MoviePipelineQueueSubsystem", "MovieRenderQueueSubsystem")
    _CLASS_NAMES = ("MoviePipelineQueueSubsystem", "MovieRenderQueueSubsystem",
                    "MoviePipelinePIEExecutor", "MoviePipelineInProcessExecutor",
                    "MoviePipelineEditorExecutor", "MoviePipelineExecutorJob",
                    "MoviePipelinePrimaryConfig", "MoviePipeline")

    def probe(self) -> Dict[str, Any]:
        """Detect MRQ subsystem exposure on the live editor (read-only)."""
        class_names = json.dumps(list(self._CLASS_NAMES))
        subsystem_names = json.dumps(list(self._SUBSYSTEM_NAMES))
        code = (
            "import unreal\n"
            "import json\n"
            "found = {}\n"
            "for name in " + class_names + ":\n"
            "    found[name] = hasattr(unreal, name)\n"
            "classes_present = [k for k, v in found.items() if v]\n"
            "subsystem_ok = False\n"
            "subsystem_error = None\n"
            "for name in " + subsystem_names + ":\n"
            "    if name in classes_present:\n"
            "        try:\n"
            "            sub = unreal.get_editor_subsystem(getattr(unreal, name))\n"
            "            if sub is not None:\n"
            "                subsystem_ok = True\n"
            "                break\n"
            "        except Exception as exc:\n"
            "            subsystem_error = str(exc)[:200]\n"
            "__bridge_result__ = {\n"
            "    \"ok\": bool(classes_present and subsystem_ok),\n"
            "    \"supported\": bool(classes_present and subsystem_ok),\n"
            "    \"classes_present\": classes_present,\n"
            "    \"classes_checked\": sorted(found.keys()),\n"
            "    \"subsystem_ok\": subsystem_ok,\n"
            "    \"subsystem_error\": subsystem_error,\n"
            "    \"note\": (\"MovieRenderPipeline plugin must be enabled in "
            "the active project for the subsystem to exist\"),\n"
            "}\n"
        )
        return self.bridge.execute_python(code)

    # ----------------------------------------------------------------- render
    def render_sequence(self, seq_path: str, out_root: str = ".", *,
                        width: int = 1920, height: int = 1080,
                        fps: int = 30, duration_s: float = 8.0,
                        output_name: str = "cinematic",
                        poll_timeout_s: float = 480.0) -> Dict[str, Any]:
        """Real MRQ render of a Level Sequence through the 5.x python surface
        (MoviePipelineQueueSubsystem / PIE executor). Truthfully BLOCKED when
        the subsystem is not exposed. The MRQ job is submitted and completion
        is detected by polling the real output PNG frames; every engine error
        is returned verbatim (never faked)."""
        out_root = str(out_root).replace("\\", "/")
        probe = self.probe()
        probe_payload = _payload(probe)
        if not isinstance(probe_payload, dict) or not probe_payload.get("supported"):
            return {
                "ok": False,
                "blocked": "movie_render_queue",
                "error": ("Movie Render Queue is not exposed by the live "
                          "editor (MovieRenderPipeline plugin not enabled in "
                          "this project); real MRQ render BLOCKED, no render "
                          "was faked"),
                "probe": probe_payload,
                "path": None,
            }

        # Subsystem present: submit a genuine MRQ job. The engine-side block
        # allocates a fresh job on the subsystem queue (existing queue jobs
        # are cleared first), configures a 1920x1080+ PNG image sequence
        # output, and hands the queue to a PIE executor.
        seq_json = json.dumps(str(seq_path))
        name_json = json.dumps(str(output_name))
        out_json = json.dumps(out_root)
        engine_submit = f'''
import unreal
import os
seq_path = {seq_json}
name = {name_json}
w = int({int(width)})
h = int({int(height)})
out_dir = {out_json}
os.makedirs(out_dir, exist_ok=True)
seq = unreal.EditorAssetLibrary.load_asset(seq_path)
if seq is None:
    __bridge_result__ = {{"ok": False, "blocked": "movie_render_queue",
                          "error": "sequence not found: " + seq_path}}
else:
    try:
        sub = None
        if hasattr(unreal, "MoviePipelineQueueSubsystem"):
            sub = unreal.get_editor_subsystem(unreal.MoviePipelineQueueSubsystem)
        if sub is None and hasattr(unreal, "MovieRenderQueueSubsystem"):
            sub = unreal.get_editor_subsystem(unreal.MovieRenderQueueSubsystem)
        if sub is None:
            __bridge_result__ = {{"ok": False, "blocked": "movie_render_queue",
                                  "error": "no MRQ subsystem exposed"}}
        else:
            q = sub.get_queue()
            try:
                if hasattr(q, "delete_all_jobs"):
                    q.delete_all_jobs()
            except Exception:
                pass
            job = q.allocate_new_job(unreal.MoviePipelineExecutorJob)
            job.job_name = name
            job.sequence = unreal.SoftObjectPath(seq_path)
            cfg = unreal.MoviePipelinePrimaryConfig()
            osetting = cfg.find_or_add_setting_by_class(
                unreal.MoviePipelineOutputSetting)
            osetting.output_resolution = unreal.IntPoint(w, h)
            osetting.file_name_format = "{{frame_number}}"
            osetting.zero_pad_frame_numbers = 4
            osetting.output_directory = unreal.DirectoryPath(out_dir)
            if hasattr(unreal, "MoviePipelineImageSequenceOutput_PNG"):
                pout = cfg.find_or_add_setting_by_class(
                    unreal.MoviePipelineImageSequenceOutput_PNG)
                try:
                    pout.format = unreal.MoviePipelineImageFormat.PNG
                except Exception:
                    pass
            job.set_configuration(cfg)
            executor = None
            if hasattr(unreal, "MoviePipelinePIEExecutor"):
                executor = unreal.MoviePipelinePIEExecutor()
            if executor is None and hasattr(unreal, "MoviePipelineEditorExecutor"):
                executor = unreal.MoviePipelineEditorExecutor()
            if executor is None:
                __bridge_result__ = {{"ok": False, "blocked": "movie_render_queue",
                                      "error": "no MRQ executor class exposed"}}
            else:
                sub.render_queue_with_executor_instance(executor)
                __bridge_result__ = {{"ok": True, "submitted": True,
                                      "renderer": "movie_render_queue",
                                      "job": str(job), "output_dir": out_dir,
                                      "width": w, "height": h,
                                      "note": "MRQ job submitted; completion "
                                              "is polled from output files"}}
    except Exception as exc:
        __bridge_result__ = {{"ok": False, "blocked": "movie_render_queue",
                              "error": str(exc)[:400],
                              "engine_closed": True}}
'''
        submitted = _payload(self.bridge.execute_python(engine_submit))
        if not (isinstance(submitted, dict) and submitted.get("ok")
                and submitted.get("submitted")):
            return {
                "ok": False,
                "blocked": "movie_render_queue",
                "error": (submitted or {}).get("error") or "MRQ submit failed",
                "probe": probe_payload,
                "path": None,
            }

        # Completion: poll the output directory for the real rendered frames.
        expected = max(1, int(round(float(duration_s) * float(fps))))
        os.makedirs(out_root, exist_ok=True)
        seen: Dict[str, int] = {}
        paths: List[str] = []
        actual: Optional[List[int]] = None
        deadline = time.time() + max(10.0, poll_timeout_s)
        while time.time() < deadline:
            files = sorted(f for f in os.listdir(out_root)
                           if f.lower().endswith(".png"))
            paths = [os.path.join(out_root, f) for f in files]
            if paths and actual is None:
                try:
                    from PIL import Image as _Im
                    actual = list(_Im.open(paths[0]).size)
                except Exception:
                    actual = None
            if len(paths) >= expected:
                break
            # stop early when the render stalls (no new frame for 30 s)
            key = f"{len(paths)}"
            seen[key] = seen.get(key, 0) + 1
            if seen[key] >= 30 and paths:
                break
            time.sleep(1.0)
        if not paths:
            return {
                "ok": False,
                "blocked": "movie_render_queue",
                "error": "MRQ job produced no output frames",
                "probe": probe_payload,
                "submitted": submitted,
                "path": out_root,
            }
        actual = actual or [int(width), int(height)]
        complete = len(paths) >= expected
        return {
            "ok": True,
            "renderer": "movie_render_queue",
            "renderer_is_mrq": True,
            "complete": complete,
            "requested_frames": expected,
            "frames": paths,
            "frame_count": len(paths),
            "frame_dir": out_root,
            "resolution": actual,
            "width": actual[0], "height": actual[1],
            "fps": int(fps),
            "duration_s": round(len(paths) / float(fps), 2),
            "probe": probe_payload,
            "note": ("Movie Render Queue (PIE executor) real render at "
                     + str(actual[0]) + "x" + str(actual[1]) + " @ "
                     + str(int(fps)) + " fps"
                     + (" (complete)" if complete else " (partial)")),
        }

    # ---------------------------------------------- real frames (non-MRQ) --
    def render_real_frames(self, seq_path: str, out_dir: str, *,
                           width: int = 1920, height: int = 1080,
                           fps: int = 30,
                           pose_paths: Optional[List[Dict[str, Any]]] = None,
                           sample_stride: float = 0.5,
                           poll_timeout_s: float = 60.0,
                           wake: Optional[Callable[[], None]] = None,
                           max_frame_retries: int = 3) -> Dict[str, Any]:
        """Capture real Unreal frames along a deterministic camera pose path.

        Each sample: the editor level-viewport camera is moved to the pose and
        a high-resolution (AutomationLibrary) screenshot captures the real
        rendered frame. MRQ is intentionally NOT claimed: this is the
        real-frame evidence path used when MRQ is unavailable.

        ``pose_paths``: list of pose dicts with location_*, pitch, yaw, roll
        (as produced by core.cinematic_director.plan_cinematic_shots).
        """
        out_dir = str(out_dir).replace("\\", "/")
        seq_json = json.dumps(str(seq_path))
        poses = [dict(p) for p in (pose_paths or [])]
        total = len(poses)
        if total == 0:
            return {"ok": False, "error": "no camera poses to render",
                    "renderer": "real_frames"}
        width, height = int(width), int(height)
        # a foregrounded, unthrottled editor is required for the viewport to
        # present (and therefore save) real frames on every sample.
        self.bridge.execute_python("""
import unreal
unreal.SystemLibrary.execute_console_command(None, "r.ThrottleCPUWhenNotForeground 0")
unreal.SystemLibrary.execute_console_command(None, "t.MaxFPS 0")
__bridge_result__ = {"ok": True}
""")
        out = {"ok": False, "renderer": "real_frames",
               "renderer_is_mrq": False,
               "missing_frames": [],
               "note": "real Unreal frames captured from the live level "
                       "viewport (native editor viewport read-back, MRQ "
                       "unavailable); not a Movie Render Queue output. "
                       "Captured at the editor viewport's real resolution."}
        paths: List[str] = []
        os.makedirs(out_dir, exist_ok=True)
        actual: Optional[List[int]] = None
        for i, pose in enumerate(poses):
            loc = [float(pose["location_x"]), float(pose["location_y"]),
                   float(pose["location_z"])]
            pitch = float(pose.get("pitch", 0.0))
            yaw = float(pose.get("yaw", 0.0))
            roll = float(pose.get("roll", 0.0))
            frame_name = f"frame_{i + 1:04d}.png"
            frame_path = os.path.join(out_dir, frame_name)
            res = self.bridge.execute_python(f'''
import unreal
loc = {json.dumps(loc)}
editor = unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem)
view_loc = unreal.Vector(loc[0], loc[1], loc[2])
view_rot = unreal.Rotator(pitch={pitch!r}, yaw={yaw!r}, roll={roll!r})
editor.set_level_viewport_camera_info(view_loc, view_rot)
readback = editor.get_level_viewport_camera_info()
__bridge_result__ = {{"ok": readback is not None}}
''')
            payload = _payload(res)
            if not (isinstance(payload, dict) and payload.get("ok")):
                out["error"] = f"frame {i + 1}: viewport camera set failed: {payload}"
                out["frames_captured"] = len(paths)
                return out
            cap = None
            frame_path = ""
            for attempt in range(1, max_frame_retries + 1):
                if wake is not None:
                    try:
                        wake()
                    except Exception:
                        pass
                cap = self._native_capture()
                cap_payload = _payload(cap)
                src = (cap_payload or {}).get("path") if isinstance(
                    cap_payload, dict) else None
                if isinstance(cap_payload, dict) and cap_payload.get("ok") and \
                        src and os.path.isfile(src):
                    import shutil
                    try:
                        shutil.copyfile(src, frame_path)
                    except OSError:
                        frame_path = ""
                    if frame_path and os.path.isfile(frame_path) \
                            and os.path.getsize(frame_path) > 0:
                        paths.append(frame_path)
                        if actual is None:
                            try:
                                from PIL import Image as _Im
                                actual = list(_Im.open(frame_path).size)
                            except Exception:
                                actual = None
                        break
                if attempt < max_frame_retries:
                    time.sleep(1.0)
            if not (frame_path and os.path.isfile(frame_path)
                    and os.path.getsize(frame_path) > 0):
                # a stubborn frame must not silently abort the film: keep the
                # frames captured so far, retry the NEXT pose, and record the
                # partial render truthfully (never a fake full-length film).
                stale = os.path.join(out_dir, frame_name)
                if os.path.isfile(stale):
                    try:
                        os.remove(stale)   # never let a stale frame stand in
                    except OSError:
                        pass
                out["missing_frames"].append(
                    {"frame": i + 1, "error": f"{cap_payload}"})
                continue
        if not paths:
            out["error"] = "no real frames captured by the render path"
            out["frames_captured"] = 0
            return out
        partial = bool(out["missing_frames"])
        w_actual = (actual or [width, height])[0]
        h_actual = (actual or [width, height])[1]
        out.update({
            "ok": True,
            "partial": partial,
            "requested_frames": total,
            "missing_count": len(out["missing_frames"]),
            "frame_dir": out_dir,
            "frames": paths,
            "frame_count": len(paths),
            "width_requested": width, "height_requested": height,
            "width": w_actual, "height": h_actual,
            "fps": int(fps),
            "duration_s": round(len(paths) * sample_stride, 2),
            "note": ("real Unreal frames captured natively from the live "
                      "level viewport at " + str(w_actual) + "x" + str(h_actual)
                      + " (MRQ unavailable); not a Movie Render Queue output"
                      + (f"; PARTIAL render ({len(paths)}/{total} frames)"
                         if partial else "")),
        })
        return out

    def _native_capture(self) -> Any:
        """Native editor-viewport capture (reliable repeated read-back)."""
        return self.bridge.capture_unreal_viewport()

    @staticmethod
    def resolution_for(requested: Any) -> List[int]:
        """Resolve a requested resolution string/list to [w, h]."""
        if isinstance(requested, (list, tuple)) and len(requested) >= 2:
            try:
                return [int(requested[0]), int(requested[1])]
            except (TypeError, ValueError):
                pass
        return list(RESOLUTION_PRESETS.get(
            str(requested).lower().strip(), (1920, 1080)))
