# Aivido V2.0.0 macOS

Install Python 3.9+ from https://www.python.org/downloads/ (or Homebrew: brew install python@3.12), then run:

    ./install-aivido.sh

The installer creates a package-local .venv and installs requirements.txt from PyPI. Control the runtime with ./start-aivido.sh start|stop|restart|status|doctor. See docs/SECOND_SYSTEM_INSTALL_MACOS.md for prerequisites and acceptance instructions.
